package Demo;

import java.util.List;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmployeeDAO employeeDAO = new EmployeeDAO();

        // Add an employee
        Employee newEmployee = new Employee();
        newEmployee.setName("John Doe");
        newEmployee.setDesignation("Software Engineer");
        newEmployee.setSalary(60000.0);
        employeeDAO.addEmployee(newEmployee);

        // Display all employees
        List<Employee> allEmployees = employeeDAO.getAllEmployees();
        System.out.println("All Employees: " + allEmployees);

        // Update an employee
        Employee employeeToUpdate = allEmployees.get(0);
        employeeToUpdate.setSalary(70000.0);
        employeeDAO.updateEmployee(employeeToUpdate);

        // Display updated employee
        Employee updatedEmployee = employeeDAO.getEmployeeById(employeeToUpdate.getId());
        System.out.println("Updated Employee: " + updatedEmployee);

        // Delete an employee
        Employee employeeToDelete = allEmployees.get(1);
        employeeDAO.deleteEmployee(employeeToDelete.getId());

        // Display all employees after deletion
        List<Employee> remainingEmployees = employeeDAO.getAllEmployees();
        System.out.println("Remaining Employees: " + remainingEmployees);
	}
}	
