package Demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {
	
	private static final String INSERT_QUERY = "INSERT INTO employees(name, designation, salary) VALUES (?,?,?)";
	private static final String UPDATE_QUERY = "UPDATE employees SET name=?, designation =?, salary=? WHERE id=?";
	private static final String DELETE_QUERY = "DELETE FROM employees WHERE id=?";
	private static final String SELECT_ALL_QUERY= "SELECT * FROM employees";
	private static final String SELECT_BY_ID_QUERY ="SELECT * FROM employees WHERE id=?";
	
	
	public void addEmployee(Employee employee) {
		try (Connection connection = DBConnectivity.getConnection();
	             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS)) {

	            preparedStatement.setString(1, employee.getName());
	            preparedStatement.setString(2, employee.getDesignation());
	            preparedStatement.setDouble(3, employee.getSalary());

	            preparedStatement.executeUpdate();

	            try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
	                if (generatedKeys.next()) {
	                    employee.setId(generatedKeys.getInt(1));
	                } else {
	                    throw new SQLException("Failed to get the generated key.");
	                }
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	public void updateEmployee(Employee employee) {
        try (Connection connection = DBConnectivity.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_QUERY)) {

            preparedStatement.setString(1, employee.getName());
            preparedStatement.setString(2, employee.getDesignation());
            preparedStatement.setDouble(3, employee.getSalary());
            preparedStatement.setInt(4, employee.getId());

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
	public void deleteEmployee(int employeeId) {
        try (Connection connection = DBConnectivity.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_QUERY)) {

            preparedStatement.setInt(1, employeeId);
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
	public List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();

        try (Connection connection = DBConnectivity.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(SELECT_ALL_QUERY)) {

            while (resultSet.next()) {
                Employee employee = new Employee();
                employee.setId(resultSet.getInt("id"));
                employee.setName(resultSet.getString("name"));
                employee.setDesignation(resultSet.getString("designation"));
                employee.setSalary(resultSet.getDouble("salary"));
                employees.add(employee);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return employees;
    }

    public Employee getEmployeeById(int employeeId) {
        Employee employee = null;

        try (Connection connection = DBConnectivity.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID_QUERY)) {

            preparedStatement.setInt(1, employeeId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    employee = new Employee();
                    employee.setId(resultSet.getInt("id"));
                    employee.setName(resultSet.getString("name"));
                    employee.setDesignation(resultSet.getString("designation"));
                    employee.setSalary(resultSet.getDouble("salary"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return employee;
    }

}
	

