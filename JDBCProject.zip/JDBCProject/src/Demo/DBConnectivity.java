package Demo;

import java.sql.Connection; //interface is part of the JDBC API and is used to establish a connection between a Java application and a relational database.
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnectivity {
	
	private static final String JDBC_URL ="jdbc:mysql://localhost:3306/db";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "1234Dhanno";
	
	public static Connection getConnection() throws SQLException{
		return DriverManager.getConnection(JDBC_URL, USERNAME,PASSWORD);
		
	}
	
	public static void closeConnection(Connection connection) {
		try {
			if(connection !=null && !connection.isClosed()) {
				connection.close();
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

}
