/**
 * 
 */
/**
 * @author HP
 *
 */
module JDBCProject {
	requires java.sql;
}